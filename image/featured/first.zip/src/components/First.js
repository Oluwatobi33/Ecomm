import React from 'react'
import myStyle from "../styles/Style"
function First() {
  let myName = "Kunle"
  let myAge = 300
//   let myStyle = {
//     color:"red",
//     backgroundColor:"black"
//   }

  return (
    <>  
        <center>
        {/* <h1 className='first'>Hello</h1> */}
        <h1 style={myStyle.header}>Hello</h1>
        <h1>{2*2}</h1>
        <h1>{myName}</h1>
        <h2 className='bg-warning'>My age is {myAge}</h2>
        </center>
    </>
  )
}

export default First