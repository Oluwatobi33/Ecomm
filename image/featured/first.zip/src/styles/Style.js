let myStyle = {
    header:{
        backgroundColor:"black",
        color:"yellow"
    },
}
export default myStyle;