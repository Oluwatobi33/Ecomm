import First from "./components/First";
import NavBar from "./components/NavBar";

const App=()=>{
  return (
    <>
      <NavBar/>
      <First/>
      <h1>Hello World</h1>
      
    </>
  )
}
export default App;